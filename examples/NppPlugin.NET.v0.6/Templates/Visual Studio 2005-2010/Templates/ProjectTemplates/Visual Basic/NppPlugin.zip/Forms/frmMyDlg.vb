Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Namespace $safeprojectname$
	Public Partial Class frmMyDlg
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace